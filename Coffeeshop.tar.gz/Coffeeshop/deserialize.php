<?php $conn = mysqli_connect("127.0.0.1","root","","coffee_shop",3306); if(!$conn){die("DB connection failed: ".mysqli_connect_error());} ?>
<?php
if(isset($_POST['data'])){
$obj=unserialize($_POST['data']);
print_r($obj);
}
?>
<form method="POST">
<textarea name="data"></textarea>
<button>Send</button>
</form>
