<?php $conn = mysqli_connect("127.0.0.1","root","","coffee_shop",3306); if(!$conn){die("DB connection failed: ".mysqli_connect_error());} ?>
<?php
$id=$_GET['id'];
$r=mysqli_query($conn,"SELECT * FROM users WHERE id='$id'");
while($row=mysqli_fetch_assoc($r)){
echo $row['username']."<br>";
}
?>
