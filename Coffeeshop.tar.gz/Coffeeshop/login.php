<?php $conn = mysqli_connect("127.0.0.1","root","","coffee_shop",3306); if(!$conn){die("DB connection failed: ".mysqli_connect_error());} ?>
<?php
if(isset($_POST['login'])){
$u=$_POST['username'];
$p=$_POST['password'];
$r=mysqli_query($conn,"SELECT * FROM users WHERE username='$u' AND password='$p'");
if(mysqli_num_rows($r)>0){
echo "Logged in";
}else{
echo "Failed";
}
}
?>
<form method="POST">
<input name="username">
<input name="password">
<button name="login">Login</button>
</form>
