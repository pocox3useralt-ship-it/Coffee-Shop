<?php $conn = mysqli_connect("127.0.0.1","root","","coffee_shop",3306); if(!$conn){die("DB connection failed: ".mysqli_connect_error());} ?>
<?php
if(isset($_POST['signup'])){
$u=$_POST['username'];
$p=$_POST['password'];
mysqli_query($conn,"INSERT INTO users(username,password) VALUES('$u','$p')");
echo "User created";
}
?>
<form method="POST">
<input name="username">
<input name="password">
<button name="signup">Signup</button>
</form>
