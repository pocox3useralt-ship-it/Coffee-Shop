<?php $conn = mysqli_connect("127.0.0.1","root","","coffee_shop",3306); if(!$conn){die("DB connection failed: ".mysqli_connect_error());} ?>
<?php session_start(); ?>
<h1>Coffee Lab</h1>
<ul>
<li><a href="login.php">Login</a></li>
<li><a href="signup.php">Signup</a></li>
<li><a href="search.php?q=test">Search</a></li>
<li><a href="upload.php">Upload</a></li>
<li><a href="ping.php?host=127.0.0.1">Ping</a></li>
<li><a href="fetch.php?url=http://example.com">Fetch</a></li>
<li><a href="view.php?file=index.php">View File</a></li>
<li><a href="profile.php?id=1">Profile</a></li>
<li><a href="redirect.php?url=https://example.com">Redirect</a></li>
<li><a href="admin.php?admin=1">Admin</a></li>
</ul>
