<?php $conn = mysqli_connect("127.0.0.1","root","","coffee_shop",3306); if(!$conn){die("DB connection failed: ".mysqli_connect_error());} ?>
<?php
if(isset($_POST['card'])){
echo "Payment received: ".$_POST['card'];
}
?>
<form method="POST">
<input name="card">
<button>Pay</button>
</form>
