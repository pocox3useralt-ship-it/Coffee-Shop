<?php $conn = mysqli_connect("127.0.0.1","root","","coffee_shop",3306); if(!$conn){die("DB connection failed: ".mysqli_connect_error());} ?>
<?php
if(isset($_POST['upload'])){
move_uploaded_file($_FILES['file']['tmp_name'],"uploads/".$_FILES['file']['name']);
echo "Uploaded";
}
?>
<form method="POST" enctype="multipart/form-data">
<input type="file" name="file">
<button name="upload">Upload</button>
</form>
