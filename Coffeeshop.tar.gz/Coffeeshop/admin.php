<?php $conn = mysqli_connect("127.0.0.1","root","","coffee_shop",3306); if(!$conn){die("DB connection failed: ".mysqli_connect_error());} ?>
<?php
if($_GET['admin']==1){
$r=mysqli_query($conn,"SELECT * FROM users");
while($row=mysqli_fetch_assoc($r)){
echo $row['username']."<br>";
}
}
?>
