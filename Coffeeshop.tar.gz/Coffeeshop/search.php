<?php $conn = mysqli_connect("127.0.0.1","root","","coffee_shop",3306); if(!$conn){die("DB connection failed: ".mysqli_connect_error());} ?>
<?php
$q=$_GET['q'];
echo "Results for: ".$q;
?>
<form>
<input name="q">
<button>Search</button>
</form>
